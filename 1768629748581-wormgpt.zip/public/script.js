const sendBtn = document.getElementById('sendBtn');
const userInput = document.getElementById('userInput');
const chatBox = document.getElementById('chatBox');

// Auto-resize Textarea
userInput.addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = (this.scrollHeight) + 'px';
    if(this.value === '') this.style.height = 'auto';
});

async function sendMessage() {
    const text = userInput.value.trim();
    if (!text) return;

    userInput.style.height = 'auto';
    userInput.value = '';
    sendBtn.disabled = true;

    // User Message
    addMessage(escapeHtml(text), 'user');
    
    // Loading State
    const loadingId = addLoading();

    try {
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: text })
        });

        const data = await response.json();
        removeMessage(loadingId);

        if (data.reply) {
            const formattedHTML = parseMarkdown(data.reply);
            addMessage(formattedHTML, 'bot', true);
        } else {
            addMessage("No response from server.", 'bot');
        }

    } catch (error) {
        removeMessage(loadingId);
        addMessage("Connection error.", 'bot');
    } finally {
        sendBtn.disabled = false;
        userInput.focus();
    }
}

// FORMATTER KEREN: Markdown to Tech UI
function parseMarkdown(markdown) {
    const rawHtml = marked.parse(markdown);
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = rawHtml;

    tempDiv.querySelectorAll('pre code').forEach((block) => {
        hljs.highlightElement(block);
        
        // Deteksi Bahasa
        let lang = 'PLAINTEXT';
        block.classList.forEach(cls => {
            if (cls.startsWith('language-')) lang = cls.replace('language-', '').toUpperCase();
        });

        const pre = block.parentElement;
        const codeContent = block.innerText;

        // Wrapper ala Window macOS/Tech
        const wrapper = document.createElement('div');
        wrapper.className = 'code-wrapper';
        wrapper.innerHTML = `
            <div class="code-header">
                <div class="window-controls">
                    <div class="dot red"></div>
                    <div class="dot yellow"></div>
                    <div class="dot green"></div>
                </div>
                <span class="lang-tag">${lang}</span>
                <button class="copy-btn" onclick="copyCode(this)">
                    <i class="fa-regular fa-clone"></i> Copy
                </button>
            </div>
            <pre>${block.outerHTML}</pre>
            <textarea style="display:none;" class="raw-code">${codeContent}</textarea>
        `;
        pre.replaceWith(wrapper);
    });

    return tempDiv.innerHTML;
}

window.copyCode = function(btn) {
    const wrapper = btn.closest('.code-wrapper');
    const code = wrapper.querySelector('.raw-code').value;
    
    navigator.clipboard.writeText(code).then(() => {
        const icon = btn.querySelector('i');
        const originalClass = icon.className;
        
        btn.innerHTML = `<i class="fa-solid fa-check"></i> Copied`;
        btn.style.color = '#4ade80';
        btn.style.borderColor = '#4ade80';

        setTimeout(() => {
            btn.innerHTML = `<i class="${originalClass}"></i> Copy`;
            btn.style.color = '';
            btn.style.borderColor = '';
        }, 2000);
    });
}

function addMessage(content, sender, isHTML = false) {
    const div = document.createElement('div');
    div.className = `message ${sender}`;
    
    const avatar = sender === 'bot' ? '<i class="fa-solid fa-bolt"></i>' : '<i class="fa-solid fa-user"></i>';
    const bubbleContent = isHTML ? content : `<p>${content}</p>`;

    div.innerHTML = `
        <div class="avatar">${avatar}</div>
        <div class="bubble">${bubbleContent}</div>
    `;
    
    chatBox.appendChild(div);
    scrollToBottom();
}

function addLoading() {
    const id = 'load-' + Date.now();
    const div = document.createElement('div');
    div.id = id;
    div.className = 'message bot';
    div.innerHTML = `
        <div class="avatar"><i class="fa-solid fa-bolt"></i></div>
        <div class="bubble" style="color: var(--primary); font-style: italic;">
            <i class="fa-solid fa-circle-notch fa-spin"></i> Processing...
        </div>
    `;
    chatBox.appendChild(div);
    scrollToBottom();
    return id;
}

function removeMessage(id) {
    const el = document.getElementById(id);
    if(el) el.remove();
}

function scrollToBottom() {
    // Scroll ke paling bawah dengan sedikit delay untuk memastikan render selesai
    setTimeout(() => {
        chatBox.scrollTop = chatBox.scrollHeight;
    }, 50);
}

function escapeHtml(text) {
    return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

sendBtn.addEventListener('click', sendMessage);
userInput.addEventListener('keydown', (e) => {
    if(e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
    }
});
